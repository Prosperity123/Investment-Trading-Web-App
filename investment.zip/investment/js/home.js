const holder_slide = document.querySelectorAll('.main-sec-2-childe')
const holder_slide_text = document.querySelectorAll('.main-sec-2-slide-text2')
const container = document.querySelectorAll('.main-slide-master')
let inital = 0
let ins = 0
function slodeaction() {
    holder_slide[0].classList.add('slide-show')
    inital++
    


holder_slide.forEach((e,value) => {
    if (value == inital ){
        e.classList.add('slide-show')

   
} else if(holder_slide.length == inital){
     inital = 0
    }
    else{
        e.classList.remove('slide-show');
     
        
    }
})

 
};
function slodeaction2() {
    holder_slide_text[0].classList.add('main-sec-2-slide-text-show')
    ins++


    holder_slide_text.forEach((ex,value2) => {
    if ( value2 == ins ){
        ex.classList.add('main-sec-2-slide-text-show')

   
} else if( holder_slide_text.length == ins){
    ins = 0
    }
    else{
        ex.classList.remove('main-sec-2-slide-text-show');
     
        
    }
})

 
}


    setInterval(() => {
    slodeaction();
    slodeaction2();
    }, 9000);



// const   chevron_right= document.querySelector('.bi-chevron-right')
const box_slit = document.querySelectorAll('.bi-chevron-rightw')
const box_slit2 = document.querySelectorAll('.lds')
const main_holider_peronves = document.querySelector('.main-holider-peronves')
const main_holider_peronves2 = document.querySelector('.main-holider-peronves2')
const slide_investores = document.querySelectorAll('.main-disv-invesy')
 let investor= slide_investores[0].clientWidth
 let normail = 0




function jjd() {
   
        main_holider_peronves2.style.transform = `translateX(${- investor * normail }px)`
        
        main_holider_peronves2.style.transition = "all 2s" 
   
}



function investore() {

box_slit[0].classList.add('currentx')

    if (normail == slide_investores.length) {
        

        normail = 0
    } else {
        main_holider_peronves2.style.transform = `translateX(${- investor * normail }px)`
        
        main_holider_peronves2.style.transition = "all 2s" 
        normail++
    }

    ;}
let auto = true
function slir() {
  box_slit.forEach((esl,vlasw) => {
    if (vlasw == normail) {
        esl.classList.add('currentx')
       
    }else if(normail == box_slit.length ){
   normail = 0
    }
     else {
        esl.classList.remove('currentx')
        
    }
});  
}
let normail2 = 0
box_slit2.forEach((edd22,valesdd) => {
    slide_investores.forEach((edd2,valesdd2) => {
    edd22.addEventListener('click',()=>{
        if (valesdd ==  valesdd2) {
            jjd()
        edd22.classList.add('currentx2')
        console.log(normail)
        clearInterval(clesx)
        normail = valesdd2

        }else if (valesdd !=  valesdd2) {
        edd22.classList.remove('currentx2')
       
        clesx
 
        }
    })
    })

});


  let clesx = setInterval(() => {
testimon_slide()
investore()
slir()
}, 9000);



const testimonail_con = document.querySelector('.main-textimonal')
const testimonail_child = document.querySelectorAll('.main-pserson-testi')
let test_chd = testimonail_child[0].clientWidth
let test_chd2 = testimonail_con.clientWidth 




let testi_inital = 1

function testimon_slide() {
    if (testi_inital >= testimonail_child.length -2) {
        testi_inital = 0
    }else if (test_chd2 <= test_chd){
        testimonail_con.style.transform = `translateX(${ test_chd - test_chd2  * testi_inital }px)`
        testi_inital++
    }
    
    else {
            testimonail_con.style.transform = `translateX(${-test_chd * testi_inital }px)`
        
        testimonail_con.style.transition = "all 2s" 
        testi_inital++
    }

}

const select_invest_con = document.querySelector('.main-output')


const inputamount = document.querySelector('.main-amount')
const submite = document.querySelector('.submite')
let returns = document.querySelector('.return')

inputamount.addEventListener('keyup',()=>{
if( select_invest_con.value === 'trial Plan'){
    if( Number(inputamount.value) <= 200){

        let resuitx = 6/100   
       resuit =  Number(inputamount.value) * Number(resuitx)
        Math.round(resuit) 
         returns.value =' $' + resuit +' every 6Days'
         
      
    } else if(Number(inputamount.value) > 200){
           returns.value = ' The inputed amount is above the maximuin subscription plan  .'
           
        } 
      else if(Number(inputamount.value) > 50){
            returns.value = '  $1000 is the maxinuim .'
            alert('sld')
         } 
    else{
        returns.value = ' $1000 is the mininuim .'

    }
}

else if(select_invest_con.value == 'brozen' ){
    if( Number(inputamount.value) <= 1000 & Number(inputamount.value) > 200 ){
        

        let resuitx = 3.5/100 
        resuit =  Number(inputamount.value) * Number(resuitx)
            
               resut = Math.floor(resuit)
            returns.value = '$'+ resut +' every 14Days(2weeks)'
    }
    else if(Number(inputamount.value) > 1000){
        returns.value = '  Note  $1000 is the maximuin .'
        
     }else{
        returns.value = ' Note $200 is the minimuin.'

    }
}
else if(select_invest_con.value == 'sliver' ){
        if( Number(inputamount.value) <= 10000 & Number(inputamount.value) > 1000){

            let resuitx = 5/100
            resuit =  Number(inputamount.value) * Number(resuitx)
                
                   resut = Math.floor(resuit)
                returns.value = '$'+ resut +' profit'
        }
        else if(Number(inputamount.value) > 1000){
            returns.value = ' $1000 is the minimuin .'
            
         }else{
            returns.value = '$200 is the minimuin .'

        }
}
else if(select_invest_con.value == 'gold' ){
    if( Number(inputamount.value) >= 10000){
        
        let resuitx = 5/100 * 10000/1
        resuit =  Number(inputamount.value) * Number(resuitx)
            
               resut = Math.floor(resuit)
            returns.value = '$'+ resut +' profit'
    }
    else{
        returns.value = ' The deposit input is less than the subscription plan amount .'

    }
}
})


const toggle_con = document.querySelector('.ul-sec-1-first')
const number_increment = document.querySelector('.js-incre')
const number_increment2 = document.querySelector('.js-incre2')
const advert_con = document.querySelector('.advert')
const advert_romver = document.querySelector('.advert-romver')
const body = document.querySelector('body')
const toggle_click = document.querySelector('.bi-justify')
const anin = document.querySelector('.anin')


let icre_nium = 100 
let icre_nium2 = 300

function icrement2() {
    if ( icre_nium2 == 6000 ) {
        icre_nium2 = 6000
    }
    else {
        
       
        icre_nium2++
        number_increment2.style.transition='all 2.5s '

        number_increment2.innerHTML = '$'+ icre_nium2
    }
}
function icrement() {
    if ( icre_nium == 23000 ) {
        icre_nium = 23000
    }
    else {
        
       
        icre_nium++
        number_increment.style.transition=' all 3s  cubic-bezier(0.165, 0.84, 0.44, 1) '

        number_increment.innerHTML =  icre_nium
    }
}

setInterval(() => {
  
    icrement() 
    icrement2() 
}, -23);
function loads() {
    anin.classList.add('aninhide')
    document.style.transition = 'all 3s  cubic-bezier(0.165, 0.84, 0.44, 1)'
    
}
setTimeout(() => {
    document.addEventListener('load',loads() )
    
}, 2000);


let normaillz = 0
let timmer = 60
let timmmerd = 44
advert_romver.addEventListener('click',()=>{
    advert_con.classList.remove('advertopen')
  
})
setInterval(() => {
    normaillz++
    if(normaillz == timmmerd){
        timmmerd = timmmerd * 3
        advert_con.classList.toggle('advertopen')
        normaillz = 0

    }
    console.log(timmmerd);
}, 6000);
toggle_click.addEventListener('click',()=>{
    toggle_con.classList.toggle('ul-sec-1-first_show')
})





setTimeout(() => {
    document.addEventListener('load',loads() )
    
}, 2000);