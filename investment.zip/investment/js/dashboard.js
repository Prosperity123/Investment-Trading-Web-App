const hide_link= document.querySelectorAll('.swsz')
const hide_icon= document.querySelectorAll('.cheronxs')
const hide_iconw= document.querySelector('.xbnxb')
const hide_iconw_child= document.querySelector('.sddshow')
const top_bar = document.querySelector('.bi-text-paragraph')
const main_con = document.querySelector('.xmain-consa')
const x_bar = document.querySelector('.bi-x')
const xsd21 = document.querySelectorAll('.xsd21')
const con_hover = document.querySelector('.main-one-con')
const main_all_con = document.querySelector(' .xmain-consa')
const main_all_con2 = document.querySelectorAll('.main-lef')
const hiddenc = document.querySelectorAll('.hiddenc')
const mediax_body = document.querySelector('.xbody')
const mediax_conhide = document.querySelector('.dsdf')
const main_lef = document.querySelector('.main-lef')
const show12 = document.querySelectorAll('.hiddenc')
let ks = true

xsd21.forEach((e) => {
    if (e.classList.contains( 'bi-bank')){

        e.classList.add('lick_show')
        e.style.color= 'white'
    }
  e.addEventListener('click',()=>{
        e.classList.add('lick_show')
        e.style.color= 'white'
  })
});


top_bar.addEventListener('click',()=>{
    top_bar.classList.toggle('bi-x');

    main_con.classList.toggle('xmain-consa-madie')


    if(ks == true){

    hide_link.forEach((e) => {
        e.style.display= "none"
         
        e.classList.toggle('main-hide-se')
     });
     hide_icon.forEach((ex) => {
         
        ex.classList.toggle('main-hide-se')
        ex.style.display= "none"
     });
     ks = false
    }else{
        hide_link.forEach((e) => {
            e.style.display= "flex"
             
            e.classList.toggle('main-hide-se')
         });
         hide_icon.forEach((ex) => {
             
            ex.classList.toggle('main-hide-se')
            ex.style.display= "flex"
         });
     ks = true

    }
    show12.forEach((e) => {
        
        e.classList.add('hidden')
        e.style.display='none'
    });
    
    
    
})
const chevron = document.querySelectorAll('.bi-chevron-down')

hide_icon.forEach((e,value) => {
    
    e.addEventListener('click',()=>{
        
        hiddenc.forEach((ex,valuex) => {
            if (value == valuex ){
                ex.classList.toggle('open-link')

            }
            else{
                ex.classList.remove('open-link')
         

 
 
            }
        });
     })
});
// document.c


let ticks = 0


  

const anin = document.querySelector('.anin')
if (anin){

    function loads() {
        anin.classList.add('aninhide')
        
    }
    setTimeout(() => {
        document.addEventListener('load',loads() )
        
    }, 2000);
}
if(hide_iconw){

    hide_iconw.addEventListener('click',()=>{
        hide_iconw_child.classList.toggle('hiddenxs')
        // alert('sksk ')
    })
}

